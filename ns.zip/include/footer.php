<footer id="footer_1" class="bg_blue p-t-100">
    <div class="container">
        <div class="row p-b-55">
            <div class="col-md-3">
                <div class="footer_logo">
                    <img src="images/nswealth.png" alt="image" />
                </div>
            </div>
            <div class="col-md-9 text-center">
                <ul class="footer_link">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about_us.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="corporate-training-modules.php">Corporate Training Modules</a></li>
                    <li><a href="career.php">Careers</a></li>
                    <li><a href="contact.php">Contact us</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer_botom m-t-50 p-t-20 p-b-20">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <p>Copyrights © 2017 Nswealth Financial. All rights reserved.</p>
                </div>
                <div class="col-md-5 text-right">
                    <p>Made with <i class="icon-heart3"></i> by <a href="http://www.nswealth.in/" target="_blank">NSwealth </a></p>
                </div>
            </div>
        </div>
    </div>
</footer>