<!DOCTYPE HTML>
<html dir="ltr" lang="en">

<head>
    <title>Nswealth </title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="">
    <meta name="description" content="">

    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">

    <!-- Required Framework -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />

    <!-- Required Framework -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
    <link rel="stylesheet" type="text/css" href="css/settings.css" />

    <!-- Fonts Icons-->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/copious-icon.css" />

    <!-- Navbar Css -->
    <link rel="stylesheet" type="text/css" href="css/bootsnav.css" />

    <!-- Custom Css -->
    <link rel="stylesheet" type="text/css" href="css/color.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>