<script src="js/jquery.2.2.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<!-- SMOOTH SCROLL -->  
<script type="text/javascript" src="js/scroll-desktop.js"></script>
<script type="text/javascript" src="js/scroll-desktop-smooth.js"></script>

<script src="js/themepunch/jquery.themepunch.revolution.min.js"></script>
<script src="js/themepunch/jquery.themepunch.tools.min.js"></script>
<script src="js/themepunch/revolution.extension.layeranimation.min.js"></script>
<script src="js/themepunch/revolution.extension.navigation.min.js"></script>
<script src="js/themepunch/revolution.extension.parallax.min.js"></script>
<script src="js/themepunch/revolution.extension.slideanims.min.js"></script>
<script src="js/themepunch/revolution.extension.video.min.js"></script>
<script src="js/tab_slider.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/bootsnav.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/viedobox/video.js"></script>
<script src="js/jquery.parallax-1.1.3.js"></script>
<script src="js/bootstrap-number-input.js"></script>
<script src="js/renge_selectbox-0.2.min.js"></script>
<script src="js/range-Slider.min.js"></script>
<script src="js/jquery.counterup.js"></script>
<script src="js/zelect.js"></script>
<!-- Progress  -->
<script src="js/progressbar.js"></script>
<script src="js/copious_custom.js"></script>