 <div class="loader">
 	<div style="color:#fff; position:absolute; font-size:20px; width:100%; text-align:center; top:30%;">NSWEALTH A client base of 163+ families from across India</div>
 	<div class="sk-rotating-plane"></div>
 </div>