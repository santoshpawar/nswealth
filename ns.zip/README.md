"# nswealth" 
