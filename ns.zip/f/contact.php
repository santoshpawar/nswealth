<?php
$errors = '';
/* Replace with your email */
$myemail = 'fargadesachin46@gmail.com';
if(empty($_POST['name']) ||
   empty($_POST['email']) ||
   empty($_POST['number']) ||
   empty($_POST['message']))
{
	$errors .= "\n Error: all fields are required";
}

$name = $_POST['name'];
$email_address = $_POST['email'];
$number = $_POST['number'];
$message = $_POST['message'];

if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i", $email_address)) {
	$errors .= "\n Error: This is invalid email address";
}

if( empty($errors) ) {
	$to = $myemail;
	$email_subject = "Contact form submission: $name";
	$email_body = "You have received a new massage. ".
	" Here are the address:\n Name: $name \n Email: $email_address \n Number: $number \n Message: $message";

	$headers = "From: $myemail\n";
	$headers .= "Reply-To: $email_address";

	mail($to,$email_subject,$email_body,$headers);
	// redirect to the 'thank you' page
	header('Location: thank-you.html');
}
?>



